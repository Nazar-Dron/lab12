import tkinter as tk
from tkinter import ttk, filedialog, messagebox, colorchooser, simpledialog
from pathlib import Path

from model import NAMES, SHAPE_ORDER, new_styles, coordinates, read_text, write_text

ROOT_DIR = Path(__file__).resolve().parent
SAMPLE = ROOT_DIR / "data" / "variants" / "v08.txt"


class App:
    def __init__(self, root):
        self.root = root
        self.root.title("ЛР 12 — Текст і геометричні фігури — Варіант 8")
        self.root.geometry("760x560")
        self.root.minsize(640, 480)
        self.styles = new_styles()
        self.current = None
        self.current_path = None

        menu = tk.Menu(root)
        files = tk.Menu(menu, tearoff=False)
        files.add_command(label="Відкрити...  Ctrl+O", command=self.open_file)
        files.add_command(label="Зберегти  Ctrl+S", command=self.save_file)
        files.add_command(label="Зберегти як...", command=self.save_as_file)
        files.add_separator()
        files.add_command(label="Вийти", command=root.destroy)
        menu.add_cascade(label="Файл", menu=files)

        opts = tk.Menu(menu, tearoff=False)
        opts.add_command(label="Налаштування зображень", command=lambda: self.settings(False))
        opts.add_command(label="Налаштування тексту", command=lambda: self.settings(True))
        menu.add_cascade(label="Налаштування", menu=opts)
        root.config(menu=menu)

        tabs = ttk.Notebook(root)
        tabs.pack(fill="both", expand=True, padx=10, pady=10)
        edit_tab = ttk.Frame(tabs)
        paint_tab = ttk.Frame(tabs)
        tabs.add(edit_tab, text="Редактор")
        tabs.add(paint_tab, text="Фігури")
        self.tabs = tabs
        self.paint_tab = paint_tab

        bar = ttk.Frame(edit_tab)
        bar.pack(fill="x", pady=(0, 8))
        ttk.Button(bar, text="Відкрити", command=self.open_file).pack(side="left", padx=(0, 8))
        ttk.Button(bar, text="Save", command=self.save_file).pack(side="left")
        ttk.Label(bar, text="UTF-8 · Ctrl+S для збереження").pack(side="left", padx=16)
        edit_frame = ttk.Frame(edit_tab)
        edit_frame.pack(fill="both", expand=True)
        self.editor = tk.Text(edit_frame, wrap="word", undo=True, font=("Consolas", 12))
        scroll = ttk.Scrollbar(edit_frame, orient="vertical", command=self.editor.yview)
        self.editor.configure(yscrollcommand=scroll.set)
        self.editor.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")

        shapes_bar = ttk.Frame(paint_tab)
        shapes_bar.pack(fill="x", pady=(0, 8))
        for key in ("triangle", "rectangle", "circle"):
            ttk.Button(shapes_bar, text=NAMES[key], command=lambda key=key: self.draw(key)).pack(
                side="left", padx=(0, 8))
        ttk.Button(shapes_bar, text="Очистити", command=self.clear).pack(side="left")
        ttk.Label(shapes_bar, text="Налаштування — у верхньому меню").pack(side="right")
        self.canvas = tk.Canvas(paint_tab, width=600, height=340, bg="white", highlightthickness=1,
                                highlightbackground="#a7a7a7")
        self.canvas.pack(fill="both", expand=True)
        self.caption = tk.Label(paint_tab, text="", font=("TkDefaultFont", 12))
        self.caption.pack(fill="x", pady=(5, 0))

        root.bind_all("<Control-s>", self._save_shortcut, add="+")
        root.bind_all("<Control-S>", self._save_shortcut, add="+")
        root.bind_all("<Control-o>", self._open_shortcut, add="+")

    def _save_shortcut(self, event=None):
        self.save_file()
        return "break"

    def _open_shortcut(self, event=None):
        self.open_file()
        return "break"

    def open_file(self):
        path = filedialog.askopenfilename(
            parent=self.root, initialdir=str(SAMPLE.parent),
            title="Відкрити текстовий файл", filetypes=[("Текст UTF-8", "*.txt"), ("Усі файли", "*.*")])
        if not path:
            return False
        try:
            content = read_text(path)
        except (OSError, UnicodeError) as error:
            messagebox.showerror("Не вдалося відкрити", str(error), parent=self.root)
            return False
        self.editor.delete("1.0", "end")
        self.editor.insert("1.0", content)
        self.current_path = None
        return True

    def save_file(self):
        return self._save(ask_path=self.current_path is None)

    def save_as_file(self):
        return self._save(ask_path=True)

    def _save(self, ask_path):
        path = self.current_path
        if ask_path:
            chosen = filedialog.asksaveasfilename(
                parent=self.root, title="Зберегти UTF-8", defaultextension=".txt",
                initialdir=str(SAMPLE.parent),
                initialfile=self.current_path.name if self.current_path else "variant8_saved.txt",
                filetypes=[("Текст UTF-8", "*.txt"), ("Усі файли", "*.*")])
            if not chosen:
                return False
            path = Path(chosen)
        content = self.editor.get("1.0", "end-1c")
        try:
            write_text(path, content)
        except OSError as error:
            messagebox.showerror("Не вдалося зберегти", str(error), parent=self.root)
            return False
        self.current_path = Path(path)
        return True

    def draw(self, name):
        if name not in self.styles:
            raise ValueError("Невідома фігура")
        self.current = name
        style = self.styles[name]
        self.canvas.delete("all")
        args = coordinates(name, style.size)
        operations = {
            "triangle": self.canvas.create_polygon,
            "rectangle": self.canvas.create_rectangle,
            "circle": self.canvas.create_oval,
        }
        operations[name](*args, fill=style.shape_color, outline="#202020", width=2)
        self.caption.config(text=NAMES[name], fg=style.text_color,
                            font=("TkDefaultFont", style.font_size))

    def clear(self):
        self.canvas.delete("all")
        self.caption.config(text="")
        self.current = None

    def settings(self, text_mode=False):
        window = tk.Toplevel(self.root)
        window.title("Налаштування тексту" if text_mode else "Налаштування зображень")
        window.transient(self.root)
        window.resizable(False, False)
        frame = ttk.Frame(window, padding=16)
        frame.grid(row=0, column=0, sticky="nsew")
        selected = tk.StringVar(value=self.current or SHAPE_ORDER[0])
        pending = {}
        ttk.Label(frame, text="Фігура:").grid(row=0, column=0, sticky="w")
        names = list(NAMES)
        combo = ttk.Combobox(frame, state="readonly", values=[NAMES[n] for n in names], width=24)
        combo.set(NAMES[selected.get()])
        combo.grid(row=0, column=1, columnspan=2, pady=4, sticky="ew")
        status = ttk.Label(frame, width=34)
        status.grid(row=1, column=0, columnspan=3, pady=8, sticky="w")

        def refresh():
            status.config(text=f"Колір: {pending['color']}; розмір: {pending['size']} " +
                               ("pt" if text_mode else "px"))

        def load_from_model(*_):
            name = names[combo.current()]
            selected.set(name)
            style = self.styles[name]
            pending["color"] = style.text_color if text_mode else style.shape_color
            pending["size"] = style.font_size if text_mode else style.size
            refresh()

        combo.bind("<<ComboboxSelected>>", load_from_model)
        combo.current(names.index(selected.get()))
        load_from_model()

        def choose_color():
            _, color = colorchooser.askcolor(color=pending["color"], parent=window)
            if color is not None:
                pending["color"] = color
                refresh()

        def choose_size():
            value = simpledialog.askinteger(
                "Розмір", "Пункти шрифту:" if text_mode else "Пікселі:",
                parent=window, initialvalue=pending["size"],
                minvalue=8 if text_mode else 40,
                maxvalue=36 if text_mode else 240)
            if value is not None:
                pending["size"] = value
                refresh()

        def apply():
            style = self.styles[selected.get()]
            if text_mode:
                style.set_text(color=pending["color"], font_size=pending["size"])
            else:
                style.set_shape(color=pending["color"], size=pending["size"])
            self.draw(selected.get())
            self.tabs.select(self.paint_tab)
            window.destroy()

        ttk.Button(frame, text="Колір", command=choose_color).grid(row=2, column=0, padx=3, pady=8)
        ttk.Button(frame, text="Розмір", command=choose_size).grid(row=2, column=1, padx=3)
        ttk.Button(frame, text="Застосувати", command=apply).grid(row=3, column=0, padx=3, pady=8)
        ttk.Button(frame, text="Скасувати", command=window.destroy).grid(row=3, column=1, padx=3)
        window.protocol("WM_DELETE_WINDOW", window.destroy)
        window.grab_set()
        combo.focus_set()
        return window


def main():
    root = tk.Tk()
    application = App(root)
    if SAMPLE.exists():
        application.editor.insert("1.0", read_text(SAMPLE))
        application.current_path = None
    root.mainloop()


if __name__ == "__main__":
    main()
