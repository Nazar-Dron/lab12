from dataclasses import dataclass
from pathlib import Path
import re

NAMES = {"triangle": "Трикутник", "rectangle": "Прямокутник", "circle": "Коло"}
SHAPE_ORDER = ("rectangle", "triangle", "circle")
MIN_SHAPE, MAX_SHAPE = 40, 240
MIN_FONT, MAX_FONT = 8, 36
COLOR_PATTERN = re.compile(r"^#[0-9a-fA-F]{6}$")


@dataclass
class Style:
    shape_color: str
    size: int
    text_color: str
    font_size: int

    def __post_init__(self):
        self._validate_color(self.shape_color)
        self._validate_color(self.text_color)
        self._validate_size(self.size, MIN_SHAPE, MAX_SHAPE)
        self._validate_size(self.font_size, MIN_FONT, MAX_FONT)

    @staticmethod
    def _validate_color(color):
        if not isinstance(color, str) or not COLOR_PATTERN.fullmatch(color):
            raise ValueError("Колір має бути у форматі #RRGGBB")

    @staticmethod
    def _validate_size(value, minimum, maximum):
        if type(value) is not int or not minimum <= value <= maximum:
            raise ValueError(f"Розмір має бути цілим числом {minimum}..{maximum}")

    def set_shape(self, *, color=None, size=None):
        if color is not None:
            self._validate_color(color)
        if size is not None:
            self._validate_size(size, MIN_SHAPE, MAX_SHAPE)
        if color is not None:
            self.shape_color = color
        if size is not None:
            self.size = size

    def set_text(self, *, color=None, font_size=None):
        if color is not None:
            self._validate_color(color)
        if font_size is not None:
            self._validate_size(font_size, MIN_FONT, MAX_FONT)
        if color is not None:
            self.text_color = color
        if font_size is not None:
            self.font_size = font_size


def new_styles():
    return {
        "triangle": Style("#1565c0", 240, "#111111", 36),
        "rectangle": Style("#2e7d32", 40, "#4a148c", 8),
        "circle": Style("#c62828", 160, "#5d4037", 24),
    }


def coordinates(shape, size, center=(240.0, 150.0)):
    if shape not in NAMES:
        raise ValueError("Невідома фігура")
    Style._validate_size(size, MIN_SHAPE, MAX_SHAPE)
    x, y = center
    if shape == "triangle":
        return (x, y-size/2, x-size/2, y+size/2, x+size/2, y+size/2)
    height = size if shape == "circle" else size * 2 / 3
    return (x-size/2, y-height/2, x+size/2, y+height/2)


def read_text(path):
    with Path(path).open("r", encoding="utf-8", newline="") as stream:
        return stream.read()


def write_text(path, content):
    if not isinstance(content, str):
        raise TypeError("Вміст має бути рядком")
    with Path(path).open("w", encoding="utf-8", newline="") as stream:
        stream.write(content)
