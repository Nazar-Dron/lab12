import json
import platform
import sys
import tkinter
from pathlib import Path
from model import NAMES, SHAPE_ORDER, coordinates, new_styles, read_text, write_text

BASE = Path(__file__).resolve().parent


def main():
    source = BASE / "data" / "variants" / "v08.txt"
    output = BASE / "results"
    output.mkdir(exist_ok=True)
    initial = read_text(source)
    edited = initial + "\nЗміни збережено у UTF-8."
    path = output / "variant8_edited.txt"
    write_text(path, edited)
    assert read_text(path) == edited
    assert not read_text(source).endswith("\n")
    styles = new_styles()
    before = {name: vars(style).copy() for name, style in styles.items()}
    styles["rectangle"].set_shape(size=176)
    styles["triangle"].set_text(font_size=35)
    after = {name: vars(style).copy() for name, style in styles.items()}
    assert styles["circle"].size == 160
    assert styles["rectangle"].font_size == 8
    assert styles["triangle"].size == 240
    result = {
        "variant": 8,
        "python": sys.version.split()[0],
        "tcl": tkinter.TclVersion,
        "tk_library_version": tkinter.TkVersion,
        "platform": platform.platform(),
        "input_exact": initial,
        "input_ends_newline": initial.endswith("\n"),
        "edited_exact": edited,
        "edited_matches_file": read_text(path) == edited,
        "show_order": list(SHAPE_ORDER),
        "styles_before": before,
        "styles_after": after,
        "circle_160_bbox": coordinates("circle", 160),
        "circle_40_bbox": coordinates("circle", 40),
        "rectangle_176_bbox": coordinates("rectangle", 176),
        "note": "Перевірено файлову й модельну логіку, не натискання клавіш або системні діалоги.",
    }
    (output / "logic_results.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print("Початковий текст:", repr(initial))
    print("Змінений текст:", repr(edited))
    print("Порядок:", " → ".join(NAMES[key] for key in SHAPE_ORDER))
    print("Прямокутник після зміни: 176 px")
    print("Підпис трикутника після зміни: 35 pt")
    print("Байти відтворено точно:", read_text(path) == edited)
    print("Файл:", path.relative_to(BASE))


if __name__ == "__main__":
    main()
