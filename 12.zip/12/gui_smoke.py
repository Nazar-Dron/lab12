import json
import tempfile
from pathlib import Path
from unittest.mock import patch
import tkinter as tk
from tkinter import ttk

from app import App
from model import read_text, write_text

BASE = Path(__file__).resolve().parent


def find_widgets(root, widget_type):
    out = []
    for child in root.winfo_children():
        if isinstance(child, widget_type):
            out.append(child)
        out.extend(find_widgets(child, widget_type))
    return out


def find_button(root, label):
    return next(w for w in find_widgets(root, ttk.Button) if w.cget('text') == label)


def do_settings(app, shape, text_mode, *, color=None, size=None):
    w = app.settings(text_mode)
    app.root.update()
    combo = find_widgets(w, ttk.Combobox)[0]
    from model import NAMES
    names = list(NAMES)
    combo.current(names.index(shape))
    combo.event_generate("<<ComboboxSelected>>")
    app.root.update()
    if color is not None:
        with patch('app.colorchooser.askcolor', return_value=((0, 0, 0), color)):
            find_button(w, 'Колір').invoke()
    if size is not None:
        with patch('app.simpledialog.askinteger', return_value=size):
            find_button(w, 'Розмір').invoke()
    find_button(w, 'Застосувати').invoke()
    app.root.update()


def capture(root, dst):
    from PIL import ImageGrab
    root.update_idletasks()
    root.update()
    x, y = root.winfo_rootx(), root.winfo_rooty()
    width, height = root.winfo_width(), root.winfo_height()
    image = ImageGrab.grab(bbox=(x, y, x+width, y+height), xdisplay=None)
    image.save(dst)
    return str(dst.relative_to(BASE))


def main():
    root = tk.Tk()
    app = App(root)
    root.update()
    checks = []
    with tempfile.TemporaryDirectory() as tmp:
        folder = Path(tmp)
        input_path = BASE/'data/variants/v08.txt'
        with patch('app.filedialog.askopenfilename', return_value=str(input_path)):
            assert app.open_file()
        assert app.editor.get('1.0', 'end-1c') == read_text(input_path)
        assert app.current_path is None
        checks.append('Open UTF-8 and source protection: OK')

        app.editor.insert('end-1c', '\nТретій рядок')
        saved = folder/'saved.txt'
        with patch('app.filedialog.asksaveasfilename', return_value=str(saved)):
            assert app.save_file()
        assert read_text(saved) == 'Перший рядок\nДругий рядок\nТретій рядок'
        checks.append('First Save UTF-8 roundtrip: OK')

        app.editor.insert('end-1c', '!')
        assert app._save_shortcut() == 'break'
        assert read_text(saved).endswith('Третій рядок!')
        checks.append('Ctrl+S handler direct invoke: OK (physical key untested)')

        with patch('app.filedialog.askopenfilename', return_value=''):
            unchanged = app.editor.get('1.0', 'end-1c')
            assert not app.open_file()
            assert app.editor.get('1.0', 'end-1c') == unchanged
        checks.append('Cancel Open: OK')

        with patch('app.filedialog.asksaveasfilename', return_value=''):
            assert not app.save_as_file()
        checks.append('Cancel Save As: OK')

        with patch('app.filedialog.askopenfilename', return_value=str(folder/'missing.txt')):
            with patch('app.messagebox.showerror') as error:
                assert not app.open_file()
                assert error.called
                assert app.editor.get('1.0', 'end-1c') == unchanged
        checks.append('Open OSError keeps editor: OK')

        app.tabs.select(app.paint_tab)
        for name in ('rectangle', 'triangle', 'circle'):
            app.draw(name)
            root.update()
            assert app.current == name
            assert app.caption.cget('text')
        checks.append('Draw rectangle > triangle > circle: OK')

        do_settings(app, 'rectangle', False, size=176)
        assert app.styles['rectangle'].size == 176
        do_settings(app, 'triangle', True, size=35)
        assert app.styles['triangle'].font_size == 35
        checks.append('Settings dialogs Apply: rectangle 176, triangle text 35: OK')

        do_settings(app, 'triangle', False, color='#aa3300')
        do_settings(app, 'circle', False, size=200)
        do_settings(app, 'rectangle', True, color='#662288')
        assert app.styles['rectangle'].shape_color == '#2e7d32'
        assert app.styles['triangle'].text_color == '#111111'
        assert app.styles['circle'].shape_color == '#c62828'
        checks.append('Independent colors and sizes: OK')

        w = app.settings(False)
        with patch('app.colorchooser.askcolor', return_value=(None, None)):
            find_button(w, 'Колір').invoke()
        with patch('app.simpledialog.askinteger', return_value=None):
            find_button(w, 'Розмір').invoke()
        find_button(w, 'Скасувати').invoke()
        assert app.styles['circle'].size == 200
        checks.append('Cancel color/size/settings preserves data: OK')

        app.draw('rectangle')
        root.update()
        first = capture(root, BASE/'screenshots/rectangle_gui.png')
        app.clear()
        assert app.canvas.find_all() == ()
        assert app.caption.cget('text') == ''
        assert app.styles['rectangle'].size == 176
        app.draw('triangle')
        root.update()
        second = capture(root, BASE/'screenshots/triangle_gui.png')
        checks.append('Clear and redraw keeps styles: OK')

    result = {'scenario': 'Virtual display Xvfb, actual Tk widgets, scripted interaction, dialogs patched',
              'checks': checks, 'screenshots': [first, second],
              'ctrl_s_note': 'Викликано реальний обробник; фізичне натискання Ctrl+S не симульовано.',
              'gui_manual_note': 'Скріншоти показують справжні пікселі Tk, але це автоматизований, не ручний запуск.',
              'tcl': root.tk.call('info', 'patchlevel'), 'tk': root.tk.call('package', 'require', 'Tk')}
    (BASE/'results/gui_smoke_results.json').write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding='utf-8')
    print('\n'.join(checks))
    print('Tk/Tcl:', result['tk'], '/', result['tcl'])
    print('Screenshots:', first, second)
    root.destroy()


if __name__ == '__main__':
    main()
