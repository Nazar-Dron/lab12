import tempfile
import unittest
from pathlib import Path

from model import Style, NAMES, SHAPE_ORDER, coordinates, new_styles, read_text, write_text


class ModelTests(unittest.TestCase):
    def test_variant8_initial_values(self):
        s = new_styles()
        self.assertEqual([s[x].size for x in ("triangle", "rectangle", "circle")], [240, 40, 160])
        self.assertEqual([s[x].font_size for x in ("triangle", "rectangle", "circle")], [36, 8, 24])
        self.assertEqual([s[x].shape_color for x in NAMES], ["#1565c0", "#2e7d32", "#c62828"])
        self.assertEqual(SHAPE_ORDER, ("rectangle", "triangle", "circle"))

    def test_styles_are_independent(self):
        styles = new_styles()
        self.assertEqual(len({id(x) for x in styles.values()}), 3)
        styles["rectangle"].set_shape(size=176)
        self.assertEqual(styles["triangle"].size, 240)
        self.assertEqual(styles["circle"].size, 160)

    def test_shape_and_caption_independent(self):
        styles = new_styles()
        styles["triangle"].set_text(font_size=35)
        self.assertEqual(styles["triangle"].shape_color, "#1565c0")
        self.assertEqual(styles["triangle"].size, 240)
        self.assertEqual(styles["triangle"].font_size, 35)
        self.assertEqual(styles["rectangle"].font_size, 8)

    def test_circle_equal_dimensions(self):
        x1, y1, x2, y2 = coordinates("circle", 160)
        self.assertEqual(x2-x1, 160)
        self.assertEqual(y2-y1, 160)

    def test_circle_40(self):
        self.assertEqual(coordinates("circle", 40), (220, 130, 260, 170))

    def test_rectangle_ratio(self):
        x1, y1, x2, y2 = coordinates("rectangle", 240)
        self.assertAlmostEqual((y2-y1)/(x2-x1), 2/3)

    def test_triangle_points(self):
        self.assertEqual(len(coordinates("triangle", 240)), 6)

    def test_boundaries_accepted(self):
        st = Style("#000000", 40, "#ffffff", 8)
        st.set_shape(size=240)
        st.set_text(font_size=36)
        self.assertEqual((st.size, st.font_size), (240, 36))

    def test_bad_sizes_leave_state(self):
        st = new_styles()["circle"]
        old = vars(st).copy()
        for value in (39, 241, True, 123.5):
            with self.assertRaises(ValueError):
                st.set_shape(size=value)
        for value in (7, 37, False):
            with self.assertRaises(ValueError):
                st.set_text(font_size=value)
        self.assertEqual(vars(st), old)

    def test_invalid_color_atomic(self):
        st = new_styles()["circle"]
        previous = vars(st).copy()
        with self.assertRaises(ValueError):
            st.set_shape(size=200, color="incorrect")
        self.assertEqual(vars(st), previous)

    def test_unknown_shape_rejected(self):
        with self.assertRaises(ValueError):
            coordinates("cube", 40)

    def test_exact_utf8_two_lines_no_final_newline(self):
        content = "Перший рядок\nДругий рядок"
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "ukr.txt"
            write_text(path, content)
            self.assertEqual(read_text(path), content)
            self.assertEqual(path.read_bytes(), content.encode("utf-8"))
            self.assertFalse(path.read_bytes().endswith(b"\n"))

    def test_empty_file_roundtrip(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "empty.txt"
            write_text(path, "")
            self.assertEqual(path.stat().st_size, 0)
            self.assertEqual(read_text(path), "")

    def test_utf8_apostrophe_and_tabs(self):
        content = "Ґанок і їжак\nоб’єкт\t42\n"
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "special.txt"
            write_text(path, content)
            self.assertEqual(read_text(path), content)

    def test_missing_file_raises(self):
        with tempfile.TemporaryDirectory() as directory:
            with self.assertRaises(FileNotFoundError):
                read_text(Path(directory) / "doesnotexist.txt")

    def test_write_type_check(self):
        with tempfile.TemporaryDirectory() as directory:
            with self.assertRaises(TypeError):
                write_text(Path(directory) / "no.txt", 1)


if __name__ == "__main__":
    unittest.main(verbosity=2)
